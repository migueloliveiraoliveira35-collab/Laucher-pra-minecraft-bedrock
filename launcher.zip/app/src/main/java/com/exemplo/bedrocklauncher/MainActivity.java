package com.exemplo.bedrocklauncher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String MC = "com.mojang.minecraftpe";
    private static final int PICK_FILE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(64, 64, 64, 64);
        root.setBackgroundColor(0xFF1E1E1E);

        TextView title = new TextView(this);
        title.setText("Bedrock Launcher");
        title.setTextSize(28);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, params(0, 0, 0, 64));

        Button play = new Button(this);
        play.setText("Abrir Minecraft Bedrock");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMinecraft();
            }
        });
        root.addView(play, params(0, 0, 0, 32));

        Button imp = new Button(this);
        imp.setText("Importar .mcpack / .mcaddon / .mcworld");
        imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickFile();
            }
        });
        root.addView(imp, params(0, 0, 0, 32));

        setContentView(root);
    }

    private LinearLayout.LayoutParams params(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(l, t, r, b);
        return p;
    }

    private void openMinecraft() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(MC);
        if (launch != null) {
            startActivity(launch);
        } else {
            Toast.makeText(this, "Minecraft Bedrock nao encontrado. Instale pela Play Store.",
                    Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=" + MC)));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + MC)));
            }
        }
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(data.getData(), "application/octet-stream");
            view.setPackage(MC);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivity(view);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Nao consegui abrir esse arquivo no Minecraft.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
